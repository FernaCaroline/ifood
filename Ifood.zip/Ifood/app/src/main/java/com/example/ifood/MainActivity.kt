package com.example.ifood

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ifood.ui.theme.ProjetoIfoodTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ProjetoIfoodTheme {
                primeiraTela()
            }
        }
    }
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Preview(showBackground = true)
@Composable
fun primeiraTela() {

    Scaffold {
        Column(modifier = Modifier.padding(16.dp)) {

            // Título das promoções
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Promoções",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                bloco("Ganhe descontos ao fazer pedidos", "Compre a partir de R$0,99", Color.LightGray, 350.dp, 150.dp)
                Spacer(modifier = Modifier.width(8.dp))
                bloco("Desconto de 50%", "Aproveite até 50% OFF", Color.Red, 350.dp, 160.dp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                bloco("tudo", "50% off", Color.Red, 350.dp, 150.dp)
                Spacer(modifier = Modifier.width(8.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row {
                Text("Restaurantes com Cupom", fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(8.dp))

            val restaurantes = listOf("Restaurante 1", "Restaurante 2", "Restaurante 3", "Restaurante 4", "Restaurante 5")
            LazyRow {
                items(restaurantes) { restaurante ->
                    bloco(restaurante, "Cupom disponível", Color.Blue, 100.dp, 100.dp)
                }
            }
        }
    }
}

@Composable
fun bloco(titulo: String, desc: String, color: Color, largura: Dp, altura: Dp) {
    Surface(
        modifier = Modifier
            .width(largura)
            .height(altura)

            .padding(5.dp)
            .clip(RoundedCornerShape(16.dp)),
        color = color,
        shadowElevation = 6.dp,
        tonalElevation = 6.dp,
        border = BorderStroke(2.dp, Color.Black)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(
                text = titulo,
                style = MaterialTheme.typography.titleLarge,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = desc,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Black
            )
        }
    }
}